import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * 
 */

/**
 * @author Owner
 *
 */
class ManagementCompanyTestStudent {
	
	ManagementCompany mgm1;
	ManagementCompany mgm2;
	ManagementCompany mgm3;
	Property prop1;
	Property prop2;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		mgm1 = new ManagementCompany();
		mgm2 = new ManagementCompany("company2", "544455", 2);
		mgm3 = new ManagementCompany("company3", "221555", 4, 0, 0, 10, 10);
		prop1 = new Property();
		prop2 = new Property();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		mgm1 = null;
		mgm2 = null;
		mgm3 = null;
		prop1 = null;
		prop2 = null;
		
	}
	
	/**
	 * @summary ensures that the addProperty method is functional
	 */

	@Test
	void testAddProperty() {
		assertEquals(mgm1.addProperty(prop1), 0);
		assertEquals(mgm1.addProperty(prop2), -4);
	}
	
	//Author: Aidan Buergin

}
